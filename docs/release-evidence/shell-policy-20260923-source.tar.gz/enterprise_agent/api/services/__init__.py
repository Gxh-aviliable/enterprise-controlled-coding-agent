"""Shared API-level services."""
