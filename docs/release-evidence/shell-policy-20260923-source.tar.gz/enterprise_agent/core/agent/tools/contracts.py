"""Uniform metadata and normalized result contract for Agent tools."""

from __future__ import annotations

import json
import shlex
from dataclasses import asdict, dataclass
from enum import Enum
from pathlib import Path
from typing import Any, Iterable

from enterprise_agent.config.settings import settings


class RiskLevel(str, Enum):
    SAFE = "safe"
    REVIEW = "review"
    DANGEROUS = "dangerous"


class ToolResultStatus(str, Enum):
    SUCCESS = "success"
    ERROR = "error"
    BLOCKED = "blocked"
    TIMEOUT = "timeout"
    REJECTED = "rejected"


class ArtifactPolicy(str, Enum):
    """Decide whether one tool result belongs in recoverable artifact storage."""

    NEVER = "never"
    RECOVERABLE = "recoverable"
    ALWAYS = "always"


@dataclass(frozen=True)
class ToolContract:
    name: str
    risk: RiskLevel
    timeout_seconds: int
    max_retries: int = 0
    idempotent: bool = False
    requires_confirmation: bool = False
    side_effect: str = "none"
    artifact_policy: ArtifactPolicy = ArtifactPolicy.RECOVERABLE


@dataclass(frozen=True)
class ToolExecutionRecord:
    tool_name: str
    tool_call_id: str
    status: ToolResultStatus
    ok: bool
    output: str
    duration_ms: int
    attempt_count: int
    error_code: str | None = None
    exit_code: int | None = None
    artifact_path: str | None = None
    artifact_sha256: str | None = None
    artifact_bytes: int | None = None
    original_chars: int | None = None
    model_chars: int | None = None
    source_truncated: bool = False
    model_truncated: bool = False
    artifact_redacted: bool = False
    artifact_error: str | None = None
    child_id: str | None = None
    execution_ids: tuple[str, ...] = ()

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["status"] = self.status.value
        return data


def _contract(
    name: str,
    *,
    risk: RiskLevel = RiskLevel.SAFE,
    timeout: int = 30,
    retries: int = 1,
    idempotent: bool = True,
    confirmation: bool = False,
    side_effect: str = "none",
    artifact_policy: ArtifactPolicy = ArtifactPolicy.RECOVERABLE,
) -> ToolContract:
    return ToolContract(
        name=name,
        risk=risk,
        timeout_seconds=timeout,
        max_retries=retries if idempotent else 0,
        idempotent=idempotent,
        requires_confirmation=confirmation,
        side_effect=side_effect,
        artifact_policy=artifact_policy,
    )


# One entry is required for every tool in ALL_TOOLS. Defaults are deliberately
# conservative for tools that mutate files, run processes, or coordinate agents.
TOOL_CONTRACTS = {
    # File tools
    "read_file": _contract("read_file"),
    "write_file": _contract(
        "write_file", risk=RiskLevel.REVIEW, idempotent=False,
        confirmation=True, side_effect="filesystem_write",
    ),
    "edit_file": _contract(
        "edit_file", risk=RiskLevel.REVIEW, idempotent=False,
        confirmation=True, side_effect="filesystem_write",
    ),
    "delete_paths": _contract(
        "delete_paths", risk=RiskLevel.DANGEROUS, idempotent=False,
        confirmation=True, side_effect="filesystem_delete",
    ),
    # Process tools
    "bash": _contract(
        "bash", risk=RiskLevel.REVIEW,
        timeout=settings.COMMAND_TIMEOUT_SECONDS + 5,
        idempotent=False, confirmation=True, side_effect="process",
    ),
    "background_run": _contract(
        "background_run", risk=RiskLevel.REVIEW,
        timeout=settings.COMMAND_TIMEOUT_SECONDS + 5,
        idempotent=False, confirmation=True, side_effect="background_process",
    ),
    "check_background": _contract("check_background"),
    # Operational task state
    "todo_update": _contract("todo_update", idempotent=False, side_effect="task_state"),
    "task_create": _contract(
        "task_create", risk=RiskLevel.REVIEW, idempotent=False,
        confirmation=True, side_effect="task_state",
    ),
    "task_get": _contract("task_get"),
    "task_update": _contract("task_update", idempotent=False, side_effect="task_state"),
    "task_list": _contract("task_list"),
    "claim_task": _contract("claim_task", idempotent=False, side_effect="task_state"),
    # Delegation and team coordination
    "task": _contract(
        "task", risk=RiskLevel.REVIEW,
        timeout=settings.AGENT_INVOKE_TIMEOUT_SECONDS,
        idempotent=False, confirmation=True, side_effect="subagent",
    ),
    "delegate_task": _contract(
        "delegate_task", risk=RiskLevel.REVIEW,
        timeout=settings.AGENT_INVOKE_TIMEOUT_SECONDS,
        idempotent=False, confirmation=True, side_effect="subagent",
    ),
    "spawn_teammate": _contract(
        "spawn_teammate", risk=RiskLevel.REVIEW,
        timeout=settings.AGENT_INVOKE_TIMEOUT_SECONDS,
        idempotent=False, confirmation=True, side_effect="subagent",
    ),
    "list_teammates": _contract("list_teammates"),
    "send_message": _contract(
        "send_message", risk=RiskLevel.REVIEW, idempotent=False,
        confirmation=True, side_effect="agent_message",
    ),
    "read_inbox": _contract("read_inbox"),
    "broadcast": _contract(
        "broadcast", risk=RiskLevel.REVIEW, idempotent=False,
        confirmation=True, side_effect="agent_message",
    ),
    "shutdown_request": _contract(
        "shutdown_request", risk=RiskLevel.REVIEW, idempotent=False,
        confirmation=True, side_effect="agent_control",
    ),
    "plan_approval": _contract(
        "plan_approval", risk=RiskLevel.REVIEW, idempotent=False,
        confirmation=True, side_effect="agent_control",
    ),
    "idle": _contract("idle", idempotent=False, side_effect="agent_control"),
    # Skills, context and memory
    "load_skill": _contract("load_skill"),
    "read_skill_resource": _contract("read_skill_resource"),
    "list_skills": _contract("list_skills"),
    "reload_skills": _contract("reload_skills"),
    "compress": _contract("compress", idempotent=False, side_effect="agent_state"),
    "list_transcripts": _contract("list_transcripts"),
    "get_transcript": _contract("get_transcript"),
    # Recovery reads must never create another recovery artifact. Otherwise
    # every read returns a fresh receipt that can induce an artifact-of-artifact
    # loop in the next model round.
    "read_tool_artifact": _contract(
        "read_tool_artifact",
        artifact_policy=ArtifactPolicy.NEVER,
    ),
    "context_status": _contract("context_status"),
    # ``search_memory`` already returns a bounded, redacted view. Persisting
    # that view cannot recover omitted Chroma rows and only duplicates user
    # memory inside the workspace artifact store.
    "search_memory": _contract(
        "search_memory",
        artifact_policy=ArtifactPolicy.NEVER,
    ),
    "list_memories": _contract(
        "list_memories",
        artifact_policy=ArtifactPolicy.NEVER,
    ),
}


SAFE_SHELL_BINARIES = {
    "pwd", "ls", "dir", "echo", "cat", "head", "tail", "wc", "find", "rg",
    "pytest", "ruff", "mypy", "npm", "pnpm", "yarn", "node", "python", "python3",
    "git", "go", "cargo", "make",
}

REVIEW_SHELL_TOKENS = {
    "install", "uninstall", "add", "remove", "commit", "push", "pull", "checkout",
    "switch", "merge", "rebase", "reset", "clean", "mv", "cp", "mkdir", "touch",
}

def get_tool_contract(tool_name: str) -> ToolContract:
    try:
        return TOOL_CONTRACTS[tool_name]
    except KeyError as exc:
        raise KeyError(f"No tool contract registered for {tool_name!r}") from exc


def should_persist_artifact(
    contract: ToolContract,
    *,
    raw_chars: int,
    source_truncated: bool = False,
) -> bool:
    """Apply the same artifact policy in every tool-execution runtime."""
    if contract.artifact_policy is ArtifactPolicy.NEVER:
        return False
    if contract.artifact_policy is ArtifactPolicy.ALWAYS:
        return raw_chars > 0
    return bool(
        source_truncated
        or raw_chars > settings.MICROCOMPACT_MIN_CHARS
        or raw_chars > settings.TOOL_OUTPUT_MAX_CHARS
    )


def validate_tool_contracts(tools: Iterable[Any]) -> None:
    """Raise when the executable registry and metadata registry diverge."""
    executable_names = {tool.name for tool in tools}
    contract_names = set(TOOL_CONTRACTS)
    missing = executable_names - contract_names
    stale = contract_names - executable_names
    if missing or stale:
        raise ValueError(
            f"Tool contract mismatch: missing={sorted(missing)}, stale={sorted(stale)}"
        )


def describe_tool(tool: Any) -> dict[str, Any]:
    """Return schema plus execution policy for API/trace presentation."""
    contract = get_tool_contract(tool.name)
    args_schema = getattr(tool, "args_schema", None)
    schema = args_schema.model_json_schema() if args_schema else {}
    data = asdict(contract)
    data["risk"] = contract.risk.value
    data["input_schema"] = schema
    return data


def resolve_tool_risk(tool_name: str, tool_args: dict[str, Any]) -> RiskLevel:
    """Resolve argument-sensitive risk while retaining conservative defaults."""
    contract = get_tool_contract(tool_name)
    if tool_name not in {"bash", "background_run"}:
        return contract.risk

    command = str(tool_args.get("command", ""))
    from enterprise_agent.core.agent.tools.shell import validate_command

    if validate_command(command):
        return RiskLevel.DANGEROUS

    # Shell control operators make a command harder to reason about. Keep it in
    # review even when the first executable is read-only.
    if any(operator in command for operator in ";&|<>$`\n\r(){}\\"):
        return RiskLevel.REVIEW

    try:
        parts = shlex.split(command)
    except ValueError:
        return RiskLevel.REVIEW
    if not parts:
        return RiskLevel.REVIEW

    binary = Path(parts[0]).name.lower()
    args = parts[1:]
    lowered_args = {part.lower() for part in args}
    if settings.AGENT_EXECUTOR == "docker":
        # Only simple read-only invocations can skip approval. Unknown syntax,
        # project runners and dispatching/output-writing options require REVIEW.
        if "/" in parts[0] and Path(parts[0]).parent not in {Path("/bin"), Path("/usr/bin")}:
            return RiskLevel.REVIEW
        if binary == "find" and lowered_args.intersection({
            "-exec", "-execdir", "-ok", "-okdir", "-delete", "-fprint", "-fprint0", "-fprintf", "-fls",
        }):
            return RiskLevel.REVIEW
        if binary == "rg" and any(arg.split("=", 1)[0] in {"--pre", "--hostname-bin"} for arg in args):
            return RiskLevel.REVIEW
        if binary in {"pwd", "ls", "dir", "echo", "cat", "head", "tail", "wc", "find", "rg"}:
            return RiskLevel.SAFE
        if binary in {"python", "python3", "node"} and args in (["--version"], ["-V"] if binary != "node" else ["-v"]):
            return RiskLevel.SAFE
        return RiskLevel.REVIEW
    if binary in {"python", "python3"}:
        if not args:
            return RiskLevel.REVIEW
        if args[0].lower() in {"--version", "-v"} and len(args) == 1:
            return RiskLevel.SAFE
        # Even a familiar -m entrypoint can load a workspace-shadowed module,
        # conftest or project hooks. It always needs a scoped approval.
        return RiskLevel.REVIEW
    if binary in {"pytest", "ruff", "mypy", "npm", "pnpm", "yarn", "go", "cargo", "make"}:
        return RiskLevel.REVIEW
    if binary == "node" and lowered_args not in ({"--version"}, {"-v"}):
        return RiskLevel.REVIEW
    if binary in SAFE_SHELL_BINARIES and not lowered_args.intersection(REVIEW_SHELL_TOKENS):
        return RiskLevel.SAFE
    return RiskLevel.REVIEW


def normalize_tool_result(
    *,
    tool_name: str,
    tool_call_id: str,
    raw_result: Any,
    duration_ms: int,
    attempt_count: int,
    display_output: str | None = None,
    artifact: dict[str, Any] | None = None,
    model_truncated: bool = False,
    artifact_error: str | None = None,
) -> ToolExecutionRecord:
    """Convert heterogeneous legacy tool output to one reliable result shape."""
    raw_output = str(raw_result)
    output = raw_output if display_output is None else display_output
    status = ToolResultStatus.SUCCESS
    error_code = None
    exit_code = None

    parsed = None
    if isinstance(raw_result, dict):
        parsed = raw_result
    elif isinstance(raw_result, str) and raw_result.lstrip().startswith("{"):
        try:
            parsed = json.loads(raw_result)
        except json.JSONDecodeError:
            parsed = None

    child_id = None
    if isinstance(parsed, dict) and parsed.get("kind") == "child_task_result":
        from enterprise_agent.core.execution.children import succeeded
        child_id = parsed.get("child_id")
        if not succeeded(parsed):
            error_code = str(parsed.get("error_code") or "child_failed")
            status = ToolResultStatus.TIMEOUT if parsed.get("status") == "timed_out" else ToolResultStatus.ERROR
    elif isinstance(parsed, dict) and isinstance(parsed.get("exit_code"), int):
        exit_code = parsed["exit_code"]
        stderr = str(parsed.get("stderr", ""))
        explicit_error = parsed.get("error_code")
        if explicit_error:
            error_code = str(explicit_error)
            status = (ToolResultStatus.TIMEOUT if error_code == "tool_timeout"
                      else ToolResultStatus.BLOCKED if error_code == "policy_blocked"
                      else ToolResultStatus.ERROR)
        elif exit_code != 0:
            if not parsed.get("executor") and "blocked:" in stderr.lower():
                status = ToolResultStatus.BLOCKED
                error_code = "policy_blocked"
            elif not parsed.get("executor") and ("timed out" in stderr.lower() or exit_code == -1):
                status = ToolResultStatus.TIMEOUT
                error_code = "tool_timeout"
            else:
                status = ToolResultStatus.ERROR
                error_code = "nonzero_exit"
    else:
        lowered = raw_output.lstrip().lower()
        if tool_name in {"task", "delegate_task"}:
            status = ToolResultStatus.ERROR
            error_code = "child_result_protocol_error"
        elif lowered.startswith("blocked:"):
            status = ToolResultStatus.BLOCKED
            error_code = "policy_blocked"
        elif lowered.startswith("error:") or lowered.startswith("error executing"):
            if "timeout" in lowered or "timed out" in lowered:
                status = ToolResultStatus.TIMEOUT
                error_code = "tool_timeout"
            else:
                status = ToolResultStatus.ERROR
                error_code = "tool_error"
        elif lowered.startswith("tool execution rejected"):
            status = ToolResultStatus.REJECTED
            error_code = "user_rejected"

    return ToolExecutionRecord(
        tool_name=tool_name,
        tool_call_id=tool_call_id,
        status=status,
        ok=status == ToolResultStatus.SUCCESS,
        output=output,
        duration_ms=max(0, duration_ms),
        attempt_count=max(1, attempt_count),
        error_code=error_code,
        exit_code=exit_code,
        artifact_path=artifact.get("path") if artifact else None,
        artifact_sha256=artifact.get("sha256") if artifact else None,
        artifact_bytes=artifact.get("stored_bytes") if artifact else None,
        original_chars=artifact.get("original_chars") if artifact else len(raw_output),
        model_chars=len(output),
        source_truncated=bool(artifact.get("source_truncated")) if artifact else False,
        model_truncated=model_truncated,
        artifact_redacted=bool(artifact.get("redacted")) if artifact else False,
        artifact_error=artifact_error,
        child_id=child_id,
    )
