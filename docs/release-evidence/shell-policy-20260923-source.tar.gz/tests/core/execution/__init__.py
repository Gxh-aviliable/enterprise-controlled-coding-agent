"""Execution core tests."""
