"""Observability tests."""
